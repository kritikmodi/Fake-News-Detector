from multiprocessing import context
from django.shortcuts import render
from results import get_models
import requests
import base64
import json
import logging
import pandas as pd
import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_text as text
from transformers import pipeline , AutoTokenizer, TFAutoModelForSequenceClassification
import numpy as np
import pickle
import spacy
from collections import Counter
from pprint import pprint
import wikipedia as wiki
from nltk.util import ngrams
import gensim
import re
import nltk
import torch
from nltk import tokenize
from nltk.corpus import stopwords
from nltk import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from sentence_transformers import SentenceTransformer

nltk.download('punkt')

APIKey = "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"
CONSUMER_KEY = "eJL1xOgPnXVx0DzCr5pGa8lNv"
CONSUMER_SECRET = "iDBuPdCEXZQDzsRqvNtkVcIhcdvlT8x8aW74VTm1EqXcIaPmrZ"
OAUTH_TOKEN = "1420293020080082948-Qo8PBaf5oXA1xrPryabo3C3g09xdBf"
OAUTH_TOKEN_SECRET = "HzW0KllX3NRls7pOKA0cPIbNEyAFWON9wgVODcRwlrVBi"
BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAABKRewEAAAAAem8kRGNx2U5tGTmD%2BtikqmENETI%3DCqzEWLXGEmM8WKNXRRnW0Tke4QlWw2sihgwtjpVYwnAR0QD6bo"


def load_models() :
    global clickBaitModel , sentimentModel , biasModel , classification_after_embedding_model, cae_model_tokenizer,  wikipedia_model, nlp
    classification_after_embedding_model = TFAutoModelForSequenceClassification.from_pretrained('pururaj/Test_model')
    cae_model_tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')
    clickBaitModel = pipeline(model="elozano/bert-base-cased-clickbait-news", tokenizer="elozano/bert-base-cased-clickbait-news")
    sentimentModel = pipeline(model="cardiffnlp/twitter-xlm-roberta-base-sentiment", tokenizer="cardiffnlp/twitter-xlm-roberta-base-sentiment")
    biasModel = pipeline(model="d4data/bias-detection-model", tokenizer="d4data/bias-detection-model")
    wikipedia_model = SentenceTransformer('bert-base-nli-mean-tokens')
    nlp = spacy.load("en_core_web_sm")


def keywords(sentence):
    
    doc = nlp(sentence)

    results = ([(X.text, X.label_)[0] for X in doc.ents])
    return list(set(results))

def clean_wiki_text(text):
    text = re.sub(r'==.+==', '.', text)
    text = re.sub(r'\n', ' ', text)
    text = re.sub(r'\t', ' ', text)
    text = re.sub(r'\[[0-9]+\]', ' ', text)
    text = re.sub(r' +', ' ', text)
    text = re.sub(r'\. \.', '.', text)
    return text

def content(claim, results):
    sentences = []
    found=[]
    for i in results:
        try :
            current_page = wiki.page(i)
            if current_page not in found:
                found.append(current_page)
        except :
            continue
    titles=[i.title for i in found]
    titles=[i[0] for i in topNSimilar(claim, titles)]
    for i in found:
        if i.title not in titles:
            found.remove(i)

    for i in found:
        current_content = i.content
        sentences.extend(tokenize.sent_tokenize(clean_wiki_text(current_content)))
    return sentences

def topNSimilar(claim, sentList, n=5):
    distList=[]
    for i in sentList:
        document_term_matrix = TfidfVectorizer().fit_transform([i, claim])
        dist = document_term_matrix * document_term_matrix.transpose()
        distance = dist.toarray()[0][1]

        if len(distList)<=n:
            distList.append([i, distance])
        else:
            distList=sorted(distList, key=lambda x: x[1], reverse=True)
            if distance>distList[-1][1]:
                distList.pop()
                distList.append([i, distance])
    return sorted(distList, key=lambda x: x[1], reverse=True)

def topNBert(claim, res):
    topNFacts=[i[0] for i in res]
    topNScore=[cosine_similarity( [wikipedia_model.encode(claim)], [wikipedia_model.encode(i)] )[0][0] for i in topNFacts]
    topN=zip(topNFacts, topNScore)
    return [list(i) for i in list(topN)]

def get_tweet(link) :
    id = int(link.split('/')[-1])
    tweetContent = twitterAPI.get_tweet(id)
    tweetContent = str(tweetContent[0]).split()
    return (" ".join(tweetContent))


def detect_news(news) :

    textToReply = prediction(news)
    finalNewsFeatures = getNewsFeatures(news)
    finalWikipediaResults = topNBert(news, topNSimilar(news, content(news, keywords(news))))

    
    res = []
    res.append(textToReply)
    
    for i in finalNewsFeatures :
        res.append(i)
        
    for i in finalWikipediaResults :
        res.append(i[0])

    return res

def detect_image(update , context) :
    photo_file = update.message.photo[-1].get_file()
    photo_file.download('user_photo.jpg')
    img_path = 'user_photo.jpg'
    img_text = preprocess(get_text_from_image(img_path))
    if len(img_text) > 0:
        update.message.reply_text("Waiting for the output...")
        textToReply = prediction(img_text)
        finalNewsFeatures = getNewsFeatures(news)
        update.message.reply_text(textToReply)
        update.message.reply_text("The news features are: ")
        for key , val in finalNewsFeatures.items():
            update.message.reply_text(key + ": " + val)        
    else:
        update.message.reply_text("The model was not able to parse text from the given image")

def preprocess(text) :
    PRETRAINED_MODEL_PATH = './lid.176.bin'
    model = fasttext.load_model(PRETRAINED_MODEL_PATH)
    return ' '.join([i  for i in text.split(' ') if len(i) != 1 if '__label__en' in model.predict(i, k=3)[0]])

def get_text_from_image(img_path) :
    url = "https://app.nanonets.com/api/v2/OCR/FullText"
    payload={'urls': ['MY_IMAGE_URL']}
    files=[('file',('FILE_NAME',open(img_path,'rb'),'application/pdf'))]
    headers = {}

    response = requests.request("POST", url, headers=headers, data=payload, files=files, auth=requests.auth.HTTPBasicAuth('I-yhRSzNQmxj8dfhXKUQVA55Wj_1Sqjy', ''))

    return json.loads(response.text)['results'][0]['page_data'][0]['raw_text']

def prediction(news) :
    sentences=[news]
    tokenized = cae_model_tokenizer(sentences, return_tensors="np", padding="longest")
    outputs = classification_after_embedding_model(tokenized).logits
    classifications = np.argmax(outputs, axis=1)
    if classifications[0]==0 :
        textToReply = "NEEDS TO BE VERIFIED"
    else :
        textToReply = " is NOT FAKE"
    return textToReply

def getNewsFeatures(inputText) :
    finalNewsFeatures = []
    
    results_model1 = clickBaitModel(inputText)[0]
    if(results_model1['label']=='Clickbait') :
        finalNewsFeatures.append(round((results_model1['score']*100), 2))
    else :
        finalNewsFeatures.append(round(((1-results_model1['score'])*100), 2))
    results_model2 = sentimentModel(inputText)[0]
    finalNewsFeatures.append(results_model2['label'])
    results_model3 = biasModel(inputText)[0]
    if(results_model3['label']=='Biased') :
        finalNewsFeatures.append(round((results_model3['score']*100), 2))
    else :
        finalNewsFeatures.append(round(((1-results_model3['score'])*100), 2))
    return finalNewsFeatures




load_models()


# Create your views here.
def home(request) :
    return render(request, 'index.html')

def show(request) :
    
    if request.method == 'POST':
        
        text = request.POST.get('text_input')

        res = detect_news(text)      
            
        col = 'danger'
        
        if res[2] == 'Positive' :
            col =  'success'
            
        elif res[2] == 'Neutral' : 
            col = 'warning'
    
        context_new = {
            'classification' : res[0],
            'clickbait' : res[1],
            'sentiment_colour' : col,
            'bias' : res[3]
        }
        
        return render(request, 'result.html', context=context_new)